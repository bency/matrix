#include<stdio.h>
#include<string.h>
#include<time.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#define WIDTH 54
#define HEIGH 15
int kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

int main(int argc,char *argv[]){
    long int disp = 100000000;
    struct timespec ts;
    ts.tv_sec = 0;
    ts.tv_nsec = disp;
    srand(time(NULL));
    int i,j,k;
    int ascii[HEIGH][WIDTH]={0};
    int bright[HEIGH][WIDTH] = {0};
    char layout[HEIGH][WIDTH];
    char alpha[]={' ','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'
                ,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '};
    int char_length = sizeof(alpha)/sizeof(alpha[0]);
    int green[7] = {32,37,31,33,34,35,36};
    int enph[2] = {0,1};
    int left = 0;
    for(i = 0; i< HEIGH; i++){
        for(j = 0; j < WIDTH; j++){
            layout[i][j] = ' ';
        }
    }
    for(i = 0; i < WIDTH; i++){
        if(rand()%2){
            layout[0][i] = alpha[rand()%59];
            bright[0][i] = enph[rand()%2];
            ascii[0][i] = green[1];
        }
    }
    while(!left){
        //system("clear");
        if(kbhit()){
            if(ts.tv_nsec == disp / 10){
               disp /= 10; 
            }
            else if(ts.tv_nsec == disp * 10){
                disp *= 10;
            }
            char ch = getchar();
            if(ch == '+'){
                ts.tv_nsec -= disp / 10;
            }
            else if(ch == '-'){
                ts.tv_nsec += disp / 10;
            }
            else if(ch == 'q' || ch == 'Q' || ch == 27){
                left = 1;
            }
            else if(ch == 24){
                left = 0;
            }
        }
        printf("\e[H\e[J");
        for(i = 1; i< HEIGH; i++){
            for(j = 0; j < WIDTH; j++){
                printf("\e[%d;%dm%c\e[0m",bright[i][j],ascii[i][j],layout[i][j]);
            }
            printf("\n");
        }
        printf("%c%c",8,8);
        nanosleep(&ts,NULL);
        for(i = HEIGH - 1; i > 0; i--){
            for(j = WIDTH -1; j>= 0; j--){
                if(layout[i][j] == ' ' && layout[i-1][j] != ' '){
                    layout[i][j] = alpha[rand()%char_length];
                    bright[i][j] = bright[i-1][j];
                    ascii[i][j] = green[1];
                }
                else if(layout[i-1][j] == ' '){
                    layout[i][j] = ' ';
                }
                else if(layout[i+1][j] != ' '){
                    ascii[i][j] = green[0];
                    bright[i][j] = enph[rand()%2];
                }
            }
        }
        for(i = 0; i < WIDTH; i++){
            if(rand()%2){
                layout[0][i] = alpha[rand()%char_length];
                if(layout[1][i] == ' ')
                    bright[0][i] = enph[1];
                else
                    bright[0][i] = enph[0];
                ascii[0][i] = green[rand()%2];
            }
        }
    }
    return 0;
}
