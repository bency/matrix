#/bin/bash
width=$(tput cols)
heigh=$(tput lines)
sed -i -e "s/WIDTH [0-9].*/WIDTH $width/" matrix.c
sed -i -e "s/HEIGH [0-9].*/HEIGH $heigh/" matrix.c
gcc matrix.c -o yamatrix
rm matrix.c-e
./yamatrix
